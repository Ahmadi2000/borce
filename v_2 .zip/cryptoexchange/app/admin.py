from django.contrib import admin
from .models import Fund, Stock

admin.site.register(Stock)
admin.site.register(Fund)