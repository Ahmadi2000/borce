# wecoin
cryptocurrency project
