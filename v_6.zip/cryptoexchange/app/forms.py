from django import forms
from .models import Fund, Stock



class StockForm(forms.ModelForm):
	class Meta:
		model = Stock
		fields = ["ticker"]
		exclude = ('owner',)

""" class FundForm(forms.ModelForm):
	class Meta:
		model = Fund
		fields = ["credit" , "moneyowner"] """
				