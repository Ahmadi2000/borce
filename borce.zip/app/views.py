# Copyright (c) 2019-2020 John Elder All Rights Reserved

from django.shortcuts import render, redirect
from .models import Stock
from .forms import StockForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required

def home(request):



	return render(request, 'app/home.html', {'ticker': "Enter a Ticker Symbol Above..."})



	


	

def about(request):
	return render(request, 'app/about.html', {})

@login_required
def add_stock(request):
	 
	import json 

	if request.method == 'POST':
		form = StockForm(request.POST or None)

		if form.is_valid():
			stock=form.save()
			stock.owner= request.user
			stock.save()
			messages.success(request, ("Stock Has Been Added!"))
			return redirect('add_stock')

	else:	
		ticker = Stock.objects.filter(owner=request.user)
	
		return render(request, 'app/add_stock.html', {'ticker': ticker})
		

@login_required
def delete(request, stock_id):
	item = Stock.objects.filter(owner=request.user).get(pk=stock_id)
	item.delete()
	messages.success(request, ("Stock Has Been Deleted!"))
	return redirect(delete_stock)


@login_required
def delete_stock(request):
	ticker = Stock.objects.filter(owner=request.user)
	return render(request, 'app/delete_stock.html', {'ticker': ticker})
