from django.core.files.base import endswith_cr
from django.db.models.query import prefetch_related_objects
from django.shortcuts import render, redirect
from .models import Fund, Stock
from .forms import StockForm 
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from decimal import Decimal

def home(request):



	return render(request, 'app/home.html', {'ticker': "Enter a Ticker Symbol Above..."})



	


	

def about(request):
	return render(request, 'app/about.html', {})

@login_required
def add_stock(request):
	if request.method == 'POST':
		if get_user_stock(request):
			temp = Stock.objects.get(owner = request.user ,ticker = request.POST['ticker'] )
			temp.quantity = temp.quantity + Decimal(request.POST['quantity'])
			temp.save()
			messages.success(request, ("Stock Has Been Added!"))
			return redirect('add_stock')
		else:
			temp = Stock.objects.create(ticker = request.POST['ticker'],quantity = request.POST['quantity'],owner = request.user)
			temp.save()
			messages.success(request, ("Stock Has Been Added!"))
			return redirect('add_stock')
	else:
		ticker = Stock.objects.filter(owner=request.user)
		return render(request, 'app/add_stock.html', {'ticker': ticker})			 
		


	
@login_required
def delete(request, stock_id):
	item = Stock.objects.filter(owner=request.user).get(pk=stock_id)
	item.delete()
	messages.success(request, ("Stock Has Been Deleted!"))
	return redirect(delete_stock)


""" @login_required
def delete_stock(request):
	ticker = Stock.objects.filter(owner=request.user)
	return render(request, 'app/delete_stock.html', {'ticker': ticker}) """

@login_required
def delete_stock(request):
	if request.method == 'POST':
		if get_user_stock(request):
			temp = Stock.objects.get(owner = request.user,ticker = request.POST['ticker'])
			temp.quantity = temp.quantity - Decimal(request.POST['quantity'])
			if temp.quantity > 0:
			   temp.save()
			   messages.success(request, ("thicker sold seccessfuly!"))
			   return redirect('delete_stock')
			else:
				messages.warning(request, ("ticker quantity is more than your owns"))
				return redirect('home')
		else:
			messages.warning(request, ("you do not have this stock!"))
			return redirect('home')
	else:
		ticker = Stock.objects.filter(owner=request.user)
		return render(request, 'app/delete_stock.html', {'ticker': ticker})


@login_required
def add_credit(request):
	if request.method == 'POST':
		if get_user_fund(request) :
			temp = Fund.objects.get(moneyowner = request.user)
			temp.credit = temp.credit + Decimal(request.POST['credit'])
			temp.save()
			return redirect('add_credit')
		else:
			temp = Fund.objects.create(credit = request.POST['credit'],moneyowner = request.user)
			temp.save()
			return redirect('add_credit')
	else:
		credit = Fund.objects.filter(moneyowner=request.user)
		return render(request,'app/add_credit.html',{'credit':credit})

def get_user_fund(request):
    try:
       return Fund.objects.get(moneyowner = request.user)
    except Fund.DoesNotExist:
        return False

def get_user_stock(request):
    try:
       return Stock.objects.get(owner = request.user ,ticker = request.POST['ticker'] )
    except Stock.DoesNotExist:
        return False

@login_required
def get_credit(request)	:
	if request.method == 'POST':
		if get_user_fund(request) :
			temp = Fund.objects.get(moneyowner = request.user)
			temp.credit = temp.credit - Decimal(request.POST['credit'])
			if temp.credit > 0:
			   temp.save()
			   messages.success(request, ("credit token seccessfuly!"))
			   return redirect('get_credit')
			else:
				messages.warning(request, ("token money is more than your credit!"))
				return redirect('home')
		else:
			messages.warning(request, ("you do not have any credit"))
			return redirect('get_credit')
	else:
		credit = Fund.objects.filter(moneyowner=request.user)
		return render(request,'app/get_credit.html',{'credit':credit})	

@login_required
def show_portfolio(request):
		ticker = Stock.objects.filter(owner=request.user)
		return render(request, 'app/show_portfolio.html', {'ticker': ticker})

